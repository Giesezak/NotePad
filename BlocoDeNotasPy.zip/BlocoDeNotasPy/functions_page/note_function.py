import os, random, string, time

def note_home():
    print("[1] Criar um Note", "\n[2] Ler um Note", "\n[3] Apagar um Note")
    menu_selection = input("\n\nSelecione::: ")
    if menu_selection == "1":
        create_note(note=False)
    if menu_selection == "2":
        read_note()
    elif menu_selection == "3":
        delete_annotation()

def create_folder(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

folder_name = "notes"
os.makedirs(folder_name, exist_ok=True)

def generate_random_string(length=10):
    letters = string.ascii_lowercase
    result_str = ''.join(random.choice(letters) for i in range(length))
    return result_str

def create_note(note):
    print("[0] Para voltar")
    create_action = input("Escolha o nome para seu novo Note::: ")
    if create_action == "0":
        note_home()
        
    if create_action:
        file_note = create_action + ".txt"
    else:
        file_note = "note_" + generate_random_string() + ".txt"
        
    try:
        file_config_log = os.path.join(folder_name, file_note)
        with open(file_config_log, "w") as f:
            f.write(note)
    except:
        note_home()


def read_note():
    print("[0] Para voltar")
    txt_files = [f for f in os.listdir(folder_name) if f.endswith(".txt")]
    for i, file_name in enumerate(txt_files):
        print(f"{i+1}: {file_name}")
    read_action = input("\nSelecione o Note que quer ler::: ")
    if read_action == "0":
        note_home()
    else:
        try:
            selected_file = txt_files[int(read_action) - 1]
            selected_file_path = os.path.join(folder_name, selected_file)
            with open(selected_file_path, "r") as f:
                print("\nConteúdo do arquivo '{}':\n".format(selected_file))
                print(f.read())
                print("\n")
                time.sleep(5)
                note_home()

        except:
            print("Selecione um número válido.")
            read_note()

def delete_annotation():
        print("[0] Para voltar")
        txt_files = [f for f in os.listdir(folder_name) if f.endswith(".txt")]
        for i, file_name in enumerate(txt_files):
            print(f"{i+1}: {file_name}")
            print("\n")
        delete_action = input("Selecione a anotação para apagar::: ")
        if delete_action == "0":
            note_home()
        else:
            try:
                selected_file = txt_files[int(delete_action) - 1]
                selected_file_path = os.path.join(folder_name, selected_file)
                os.remove(selected_file_path)
                print("Arquivo '{}' foi deletado, é uma pena".format(selected_file))
                note_home()
            except:
                print("Selecione um número válido.")
                delete_annotation()
    
print("Menu do NotePad!\n")
time.sleep(3)
note_home()