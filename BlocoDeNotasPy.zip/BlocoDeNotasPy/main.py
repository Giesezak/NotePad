import time, os, json, hashlib
email_domain = ["@gmail.com", "@outlook.com", "@hotmail.com", "@wwjmp.com"]

def home_page():
    print("Você gostaria de fazer:\n")
    print("[1] - Login\n")
    print("[2] - Criar Conta\n")

    choose_number = input("R: ")

    if choose_number == "1":
        login_function()
    elif choose_number == "2":
        signup_function()
    else:
        print("\nSelecione numeros entre 1-2!")
        home_page()

def login_function():
    user_input = input("email: ")
    pass_input = input("Password: ")
    if not any(domain in user_input for domain in email_domain):
        print("\nPor favor, insira um email válido.")
        login_function()

    with open("data/data_file.json") as f:
        data = json.load(f)

    pass_input = hashlib.sha256(pass_input.encode()).hexdigest()

    if user_input in data and data[user_input] == pass_input:
        print("\nVocê está logado agora!")
        from functions_page import note_function
    else:
        print("\nAlgo está errado, verifique seu email e senha.")
        login_function()


def signup_function():
    username = input("Insira o seu email: ")
    password = input("Insira a sua password: ")

    if not any(domain in username for domain in email_domain):
        print("\nPor favor, insira um email válido.")
        signup_function()

    folder_name = "data"
    os.makedirs(folder_name, exist_ok=True)
    file_log = "data_file.json"
    file_config_log = os.path.join(folder_name, file_log)

    password = hashlib.sha256(password.encode()).hexdigest()

    data = {}
    if os.path.exists(file_config_log):
        with open(file_config_log, "r") as f:
            data = json.load(f)

    data[username] = password

    with open(file_config_log, "w") as f:
        json.dump(data, f)
        print("\nConta criada com sucesso!\n\n")

print("Olá! Seja Bem Vindo ao Nosso Simples Notepad Feito em Python!\n")
time.sleep(1)
home_page()